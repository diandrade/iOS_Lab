//
//  Hero.swift
//  marvel
//
//  Created by iOSLab on 11/07/24.
//

import UIKit

struct ApiModel: Codable {
    let data: ResultModel
}

struct ResultModel: Codable {
    let results: [Hero]
}

struct Hero: Codable {
    let name: String
    let description: String 
    private let thumbnail: ThumbnailModel
    var imageData: Data?
    var imagePath: URL? {
        URL(string: thumbnail.path + "." + thumbnail.`extension`)
    }
}

struct ThumbnailModel: Codable {
    let path: String
    let `extension`: String
}
