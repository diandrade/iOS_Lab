//
//  APINetwork.swift
//  marvel
//
//  Created by iOSLab on 01/08/24.
//

import Foundation

enum NetworkError {
    case endpointError
    case requestError
    case errorData
}

class APINetwork {
    private let config = HeroAPIConfig()
    func getData(path: URL?, completion: @escaping (Data) -> Void, onError: @escaping (NetworkError) -> Void) {
        
        guard let url = path else {
            onError(.endpointError)
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data,
                  let response,
                  error == nil,
                  let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else {
                onError(.requestError)
                return
            }
            
            completion(data)
            
        }
        task.resume()
    }
    
    
        func getHeroes(completion: @escaping ([Hero]) -> Void, onError: @escaping (NetworkError) -> Void){
            getData(path: config.heroUrl) { data in
                do {
                    let json = try JSONDecoder().decode(ApiModel.self, from:data)
                    completion(json.data.results)
                } catch {
                    onError(.errorData)
                }
            } onError: { error in
                onError(error)
            }

        }
    
}


