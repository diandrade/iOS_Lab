//
//  HeroAPIConfig.swift
//  marvel
//
//  Created by iOSLab on 01/08/24.
//

import Foundation
import CryptoKit

enum ApiKeys: String {
    case privateKey = "755218009c874bee17a38d9cb2aabd8f572a2dd1"
    case publicKey = "e184a671ccf953982916b760680202c9"
}

class HeroAPIConfig {
    private let timestamp: String =
        String(Int(Date().timeIntervalSince1970 * 1000))
    
    
    var MD5: String {
        let string = timestamp  + ApiKeys.privateKey.rawValue + ApiKeys.publicKey.rawValue
        let digest = Insecure.MD5.hash(data: Data(string.utf8))
        return digest.map{
            String(format: "%02hhx", $0)
        }.joined()
    }
    
    var heroUrl: URL? {
        let base = NetworkConstants.baseURL + NetworkConstants.baseEndpoit + NetworkConstants.heroEndpoint
        let url = "\(base)?ts=\(timestamp)&apikey=\(ApiKeys.publicKey.rawValue)&hash=\(MD5)"
      return URL(string: url)
    }
}
