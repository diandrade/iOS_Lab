//
//  ViewController+HeroCellDelegate.swift
//  marvel
//
//  Created by iOSLab on 02/09/24.
//

import Foundation

extension ViewController: HeroCellDelegate {
    func saveImageHero(image: Data, index: Int) {
        heroes[index].imageData = image
    }
}
