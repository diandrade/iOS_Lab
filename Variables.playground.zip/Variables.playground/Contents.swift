var numero1:Int = 4
let numero2:Int = 3

var soma:Int = numero1 + numero2
print("Soma: \(soma)")

var sub:Int = numero1 - numero2
print("Subtração: \(sub)")

var multi:Int = numero1 * numero2
print("Multiplicação: \(multi)")

var div:Int = numero1 / numero2
print("Divisão: \(div)")


var name = "Diego"
var personalAccount:Double = 1000.5
var businessAccount:Double = 2000.5
var money:Double = personalAccount + businessAccount

print("Bem vindo \(name). Você possui \(money) na carteira")







