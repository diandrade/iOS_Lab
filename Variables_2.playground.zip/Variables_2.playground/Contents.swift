var nomePredefinido:String = "André"
var nomeEditado:String = "Diego"

var idadePredefinido:Int = 21
var idadeEditado:Int = 20

var telefonePredefinido:String = "11 326783622"
var telefoneEditado:String = "11958152477"

let residencia:String = "Rua Bartolomeu Ferrari, 780, APTO242"

var nomes:String = "Bem vindos \(nomePredefinido) e \(nomeEditado)!"
print(nomes)

var div:Double = Double(idadePredefinido)/Double(idadeEditado)
print(div)

var telefonePredefinidoToInt: Int = Int(telefonePredefinido) ?? 0
print(telefonePredefinidoToInt)








